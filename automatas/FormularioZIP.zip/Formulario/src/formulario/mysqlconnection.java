package formulario;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class mysqlconnection {
    private final String USER = "root";
    private final String PASSWORD = "casa68330994";
    private final String URL = "jdbc:mysql://localhost:3306/Formulario?serverTimezone=UTC";
    private Connection connect = null;
    
    public Connection getConexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connect = DriverManager.getConnection(URL, USER, PASSWORD);
            
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error De SQL " + e.toString());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(mysqlconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    return connect;
    }
    
}
