package formulario;

import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.plaf.ComboBoxUI;

public class App extends javax.swing.JFrame {

    public static final String URL = "jdbc:mysql://localhost:3306/Formulario";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "casa68330994";

    public App() {
        initComponents();


    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rb_grupo = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        combo_carrera = new javax.swing.JComboBox<>();
        txt_nom = new javax.swing.JTextField();
        txt_telf = new javax.swing.JTextField();
        txt_corr = new javax.swing.JTextField();
        txt_fecha = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        txt_ctrl = new javax.swing.JTextField();
        btn_reg = new javax.swing.JButton();
        btn_elim = new javax.swing.JButton();
        btn_modif = new javax.swing.JButton();
        btn_buscar = new javax.swing.JButton();
        combo_semestre = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        rb_isc = new javax.swing.JRadioButton();
        rb_ige = new javax.swing.JRadioButton();
        rb_iin = new javax.swing.JRadioButton();
        rb_ime = new javax.swing.JRadioButton();
        rb_todos = new javax.swing.JRadioButton();
        rb_ninguno = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        btn_limpiar = new javax.swing.JButton();
        txt_buscar = new javax.swing.JTextField();
        fond = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImages(null);
        setMaximumSize(new java.awt.Dimension(1280, 571));
        setMinimumSize(new java.awt.Dimension(1280, 571));
        setPreferredSize(new java.awt.Dimension(1280, 571));
        setSize(new java.awt.Dimension(1280, 571));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Numero De CTRL");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 84, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 122, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Semestre");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 157, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Telefono:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 198, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Correo Electronico:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 236, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Fecha De Nacimiento (YYY-MM-DD):");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 274, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Carrera:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 312, -1, -1));

        combo_carrera.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        combo_carrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "                                ...", "Ing. Sistemas Computacionales", "Ing. Gestion Empresarial", "Ing. Industrial", "Ing. Mecatronica" }));
        getContentPane().add(combo_carrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 309, 226, -1));

        txt_nom.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 119, 222, -1));

        txt_telf.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_telf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_telfActionPerformed(evt);
            }
        });
        getContentPane().add(txt_telf, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 195, 222, -1));

        txt_corr.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_corr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_corrActionPerformed(evt);
            }
        });
        getContentPane().add(txt_corr, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 233, 222, -1));

        txt_fecha.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_fecha.setText("              Ej. 1997-12-31");
        txt_fecha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_fechaMouseClicked(evt);
            }
        });
        txt_fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_fechaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 271, 222, -1));

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "No. Control", "Nombre", "Semestre", "Telefono", "Corre Electronico", "Fecha Nacimiento", "Carrera"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, 780, -1));

        txt_ctrl.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_ctrl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ctrlActionPerformed(evt);
            }
        });
        getContentPane().add(txt_ctrl, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 81, 222, -1));

        btn_reg.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_reg.setText("Registrar");
        btn_reg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_regActionPerformed(evt);
            }
        });
        getContentPane().add(btn_reg, new org.netbeans.lib.awtextra.AbsoluteConstraints(73, 411, 110, 35));

        btn_elim.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_elim.setText("Eliminar");
        btn_elim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_elimActionPerformed(evt);
            }
        });
        getContentPane().add(btn_elim, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 490, 100, 35));

        btn_modif.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_modif.setText("Modificar");
        btn_modif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modifActionPerformed(evt);
            }
        });
        getContentPane().add(btn_modif, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 490, 120, 35));

        btn_buscar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_buscar.setText("Buscar");
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(536, 490, 90, 35));

        combo_semestre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "                                ...", "1er Semestre", "2do Semestre", "3er Semestre", "4to Semestre", "5to Semestre", "6to Semestre", "7mo Semestre", "8vo Semestre", "9no Semestre", "10mo Semestre", "11vo Semestre", "12vo Semestre" }));
        combo_semestre.setSelectedItem(btn_reg);
        getContentPane().add(combo_semestre, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 157, 222, -1));

        rb_isc.setBackground(new java.awt.Color(255, 255, 255));
        rb_grupo.add(rb_isc);
        rb_isc.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rb_isc.setText("ISC");
        rb_isc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_iscMouseClicked(evt);
            }
        });
        rb_isc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_iscActionPerformed(evt);
            }
        });

        rb_ige.setBackground(new java.awt.Color(255, 255, 255));
        rb_grupo.add(rb_ige);
        rb_ige.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rb_ige.setText("IGE");
        rb_ige.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_igeActionPerformed(evt);
            }
        });

        rb_iin.setBackground(new java.awt.Color(255, 255, 255));
        rb_grupo.add(rb_iin);
        rb_iin.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rb_iin.setText("IIN");
        rb_iin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_iinActionPerformed(evt);
            }
        });

        rb_ime.setBackground(new java.awt.Color(255, 255, 255));
        rb_grupo.add(rb_ime);
        rb_ime.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rb_ime.setText("IME");
        rb_ime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_imeActionPerformed(evt);
            }
        });

        rb_todos.setBackground(new java.awt.Color(255, 255, 255));
        rb_grupo.add(rb_todos);
        rb_todos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rb_todos.setText("Todos");
        rb_todos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_todosActionPerformed(evt);
            }
        });

        rb_ninguno.setBackground(new java.awt.Color(255, 255, 255));
        rb_grupo.add(rb_ninguno);
        rb_ninguno.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rb_ninguno.setText("Ninguno");
        rb_ninguno.setEnabled(false);
        rb_ninguno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_ningunoMouseClicked(evt);
            }
        });
        rb_ninguno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_ningunoActionPerformed(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Mostrar:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rb_ninguno)
                    .addComponent(rb_todos)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rb_isc, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rb_iin)
                            .addComponent(rb_ige)
                            .addComponent(rb_ime))
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rb_isc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rb_ige)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rb_iin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rb_ime)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rb_todos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rb_ninguno)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(231, 355, -1, -1));

        btn_limpiar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_limpiar.setText("Limpiar");
        btn_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(73, 464, 110, 35));

        txt_buscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_buscar.setText(" Numero De Control");
        txt_buscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_buscarMouseClicked(evt);
            }
        });
        txt_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(txt_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 490, 140, 35));

        fond.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fondo/Presentació2.jpg"))); // NOI18N
        getContentPane().add(fond, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 670));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed

    }//GEN-LAST:event_txt_nomActionPerformed

    private void txt_telfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_telfActionPerformed

    }//GEN-LAST:event_txt_telfActionPerformed

    private void txt_corrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_corrActionPerformed

    }//GEN-LAST:event_txt_corrActionPerformed

    private void txt_fechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_fechaActionPerformed

    }//GEN-LAST:event_txt_fechaActionPerformed

    private void txt_ctrlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ctrlActionPerformed

    }//GEN-LAST:event_txt_ctrlActionPerformed

    private void rb_iscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_iscActionPerformed

        rb_ninguno.setEnabled(true);
        try {
            DefaultTableModel modelo = new DefaultTableModel();
            tabla.setModel(modelo);

            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();

            String datos = "SELECT No_Ctrl, Nombre, Semestre, Numero_Telefonico, Correo_Electronico, Fecha_Nacimiento, Carrera FROM alumnos WHERE Carrera = 'ISC'";
            ps = conexion.prepareStatement(datos);
            rs = ps.executeQuery();
            ResultSetMetaData rsMD = rs.getMetaData();
            int columnas = rsMD.getColumnCount();

            modelo.addColumn("No. Control");
            modelo.addColumn("Nombre");
            modelo.addColumn("Semestre");
            modelo.addColumn("Telefono");
            modelo.addColumn("Correo Electronico");
            modelo.addColumn("Fecha Nacimiento");
            modelo.addColumn("Carrera");

            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "No Existen Datos");
            } else {
                while (rs.next()) {
                    Object[] filas = new Object[columnas];
                    for (int i = 0; i < columnas; i++) {
                        filas[i] = rs.getObject(i + 1);
                    }
                    modelo.addRow(filas);
                }
            }
            conexion.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error De SQL " + ex.toString());
        }
    }//GEN-LAST:event_rb_iscActionPerformed

    private void rb_todosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_todosActionPerformed

        rb_ninguno.setEnabled(true);
        try {
            DefaultTableModel modelo = new DefaultTableModel();
            tabla.setModel(modelo);

            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();

            String datos = "SELECT No_Ctrl, Nombre, Semestre, Numero_Telefonico, Correo_Electronico, Fecha_Nacimiento, Carrera FROM alumnos";
            ps = conexion.prepareStatement(datos);
            rs = ps.executeQuery();
            ResultSetMetaData rsMD = rs.getMetaData();
            int columnas = rsMD.getColumnCount();

            modelo.addColumn("No. Control");
            modelo.addColumn("Nombre");
            modelo.addColumn("Semestre");
            modelo.addColumn("Telefono");
            modelo.addColumn("Correo Electronico");
            modelo.addColumn("Fecha Nacimiento");
            modelo.addColumn("Carrera");

            while (rs.next()) {
                Object[] filas = new Object[columnas];
                for (int i = 0; i < columnas; i++) {
                    filas[i] = rs.getObject(i + 1);
                }
                modelo.addRow(filas);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error De SQL " + ex.toString());
        }

    }//GEN-LAST:event_rb_todosActionPerformed

    private void btn_modifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modifActionPerformed
        try {
            
            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();
            ps = conexion.prepareStatement("UPDATE alumnos SET No_Ctrl=?, Nombre=?, Semestre=?, Numero_Telefonico=?, Correo_Electronico=?, Fecha_Nacimiento=?, Carrera=? WHERE No_Ctrl=?");
            int op_sem = combo_semestre.getSelectedIndex();
            int op_carr = combo_carrera.getSelectedIndex();

            if (txt_ctrl.getText().equals("") || txt_nom.getText().equals("") || txt_telf.getText().equals("") || txt_corr.getText().equals("") || txt_fecha.getText().equals("") || op_sem == 0 || op_carr == 0) {
                JOptionPane.showMessageDialog(null, "Campo(s) Vacios");
            }

            if (txt_ctrl.getText().length() < 9 || txt_ctrl.getText().length() > 9 || txt_ctrl.getText().matches(".*[a-z].*") || txt_ctrl.getText().matches(".*[A-Z].*")) {
                JOptionPane.showMessageDialog(null, "Numero De Control Invalido.\nDebe cumplir con las siguientes caracteristicas:\n1.No Espacios En Blanco\n2.No Letras\n3.Deben Ser 9 Digitos");
                txt_ctrl.setText("");
            }
            if (txt_ctrl.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo Del No. de Control Vacio");
            } else {
                ps.setString(1, txt_ctrl.getText());
            }

            //INSERT NOMBRE
            if (txt_nom.getText().length() > 50 || txt_nom.getText().equals(null) || txt_nom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Nombre Invalido");
                txt_nom.setText("");
            }
            if (txt_nom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo De Nombre Vacio");
            } else {
                ps.setString(2, txt_nom.getText());
            }
            
            //INSERT SEMESTRE
            if (op_sem == 0) {
                JOptionPane.showMessageDialog(null, "Seleccione El Semestre");
            }
            ps.setString(3, String.valueOf(op_sem));
            
            //INSERT TELEFONO O CORREO
            if (txt_telf.getText().equals("") && txt_corr.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Ingrese al menos un metodo de contacto");
            }
            if (txt_telf.getText().length() > 10 || txt_telf.getText().matches(".*[a-z].*") || txt_telf.getText().matches(".*[A-Z].*")) {
                JOptionPane.showMessageDialog(null, "Numero Telefonico No Valido");
                txt_telf.setText("");
                txt_corr.setText("");
            }
            if (!txt_telf.getText().equals("") || !txt_corr.getText().equals("")) {
                ps.setString(4, txt_telf.getText());
                ps.setString(5, txt_corr.getText());
            }

            //INSERT FECHA DE NACIMIENTO
            if (txt_fecha.getText().matches(".*[a-z].*") || txt_fecha.getText().matches(".*[A-Z].*")) {
                JOptionPane.showMessageDialog(null, "Fecha De Nacimiento Invalida");
                txt_fecha.setText("");
            }
            if (txt_fecha.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo De Fecha Vacio");
            } else {
                ps.setDate(6, Date.valueOf(txt_fecha.getText()));
            }
            //INSERT CARRERA
            if (op_carr == 0) {
                JOptionPane.showMessageDialog(null, "Seleccione La Carrrera");
            }
            if (op_carr == 1) {
                ps.setString(7, "ISC");
            }
            if (op_carr == 2) {
                ps.setString(7, "IGE");
            }
            if (op_carr == 3) {
                ps.setString(7, "IIN");
            }
            if (op_carr == 4) {
                ps.setString(7, "IME");
            }
            
            
            ps.setString(8, txt_buscar.getText());
            
            //VERFICACION Y EJECUCION DE NUESTRO QUERY
            int res = ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Alumno Acutalizado");
            } else {
                JOptionPane.showMessageDialog(null, "Error Al Actualizar Alumno");
            }
            conexion.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error" + e);
        }
    }//GEN-LAST:event_btn_modifActionPerformed

    private void rb_igeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_igeActionPerformed

        rb_ninguno.setEnabled(true);
        try {
            DefaultTableModel modelo = new DefaultTableModel();
            tabla.setModel(modelo);

            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();

            String datos = "SELECT No_Ctrl, Nombre, Semestre, Numero_Telefonico, Correo_Electronico, Fecha_Nacimiento, Carrera FROM alumnos WHERE Carrera = 'IGE'";
            ps = conexion.prepareStatement(datos);
            rs = ps.executeQuery();
            ResultSetMetaData rsMD = rs.getMetaData();
            int columnas = rsMD.getColumnCount();

            modelo.addColumn("No. Control");
            modelo.addColumn("Nombre");
            modelo.addColumn("Semestre");
            modelo.addColumn("Telefono");
            modelo.addColumn("Correo Electronico");
            modelo.addColumn("Fecha Nacimiento");
            modelo.addColumn("Carrera");

            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "No Existen Datos");
            } else {
                while (rs.next()) {
                    Object[] filas = new Object[columnas];
                    for (int i = 0; i < columnas; i++) {
                        filas[i] = rs.getObject(i + 1);
                    }
                    modelo.addRow(filas);
                }
            }
            conexion.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error De SQL " + ex.toString());
        }
    }//GEN-LAST:event_rb_igeActionPerformed

    private void rb_iinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_iinActionPerformed

        rb_ninguno.setEnabled(true);
        try {
            DefaultTableModel modelo = new DefaultTableModel();
            tabla.setModel(modelo);

            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();

            String datos = "SELECT No_Ctrl, Nombre, Semestre, Numero_Telefonico, Correo_Electronico, Fecha_Nacimiento, Carrera FROM alumnos WHERE Carrera = 'IIN'";

            ps = conexion.prepareStatement(datos);
            rs = ps.executeQuery();
            ResultSetMetaData rsMD = rs.getMetaData();
            int columnas = rsMD.getColumnCount();

            modelo.addColumn("No. Control");
            modelo.addColumn("Nombre");
            modelo.addColumn("Semestre");
            modelo.addColumn("Telefono");
            modelo.addColumn("Correo Electronico");
            modelo.addColumn("Fecha Nacimiento");
            modelo.addColumn("Carrera");

            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "No Existen Datos");
            } else {
                while (rs.next()) {
                    Object[] filas = new Object[columnas];
                    for (int i = 0; i < columnas; i++) {
                        filas[i] = rs.getObject(i + 1);
                    }
                    modelo.addRow(filas);
                }
            }
            conexion.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error De SQL" + ex.toString());
        }

    }//GEN-LAST:event_rb_iinActionPerformed

    private void rb_imeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_imeActionPerformed

        rb_ninguno.setEnabled(true);
        try {
            DefaultTableModel modelo = new DefaultTableModel();
            tabla.setModel(modelo);

            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();

            String datos = "SELECT No_Ctrl, Nombre, Semestre, Numero_Telefonico, Correo_Electronico, Fecha_Nacimiento, Carrera FROM alumnos WHERE Carrera = 'IME'";
            ps = conexion.prepareStatement(datos);
            rs = ps.executeQuery();
            ResultSetMetaData rsMD = rs.getMetaData();
            int columnas = rsMD.getColumnCount();

            modelo.addColumn("No. Control");
            modelo.addColumn("Nombre");
            modelo.addColumn("Semestre");
            modelo.addColumn("Telefono");
            modelo.addColumn("Correo Electronico");
            modelo.addColumn("Fecha Nacimiento");
            modelo.addColumn("Carrera");

            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "No Existen Datos");
            } else {
                while (rs.next()) {
                    Object[] filas = new Object[columnas];
                    for (int i = 0; i < columnas; i++) {
                        filas[i] = rs.getObject(i + 1);
                    }
                    modelo.addRow(filas);
                }
            }
            conexion.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error De SQL " + ex.toString());
        }

    }//GEN-LAST:event_rb_imeActionPerformed

    private void txt_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_buscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_buscarActionPerformed

    private void txt_buscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_buscarMouseClicked
    txt_buscar.setText("");
    }//GEN-LAST:event_txt_buscarMouseClicked

    private void btn_regActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_regActionPerformed

        try {
            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();
            ps = conexion.prepareStatement("INSERT INTO alumnos(No_Ctrl, Nombre, Semestre, Numero_Telefonico, Correo_Electronico, Fecha_Nacimiento, Carrera) VALUES(?,?,?,?,?,?,?)");
            int op_sem = combo_semestre.getSelectedIndex();
            int op_carr = combo_carrera.getSelectedIndex();

            if (txt_ctrl.getText().equals("") || txt_nom.getText().equals("") || txt_telf.getText().equals("") || txt_corr.getText().equals("") || txt_fecha.getText().equals("") || op_sem == 0 || op_carr == 0) {
                JOptionPane.showMessageDialog(null, "Campo(s) Vacios");
            }

            if (txt_ctrl.getText().length() < 9 || txt_ctrl.getText().length() > 9 || txt_ctrl.getText().matches(".*[a-z].*") || txt_ctrl.getText().matches(".*[A-Z].*")) {
                JOptionPane.showMessageDialog(null, "Numero De Control Invalido.\nDebe cumplir con las siguientes caracteristicas:\n1.No Espacios En Blanco\n2.No Letras\n3.Deben Ser 9 Digitos");
                txt_ctrl.setText("");
            }
            if (txt_ctrl.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo Del No. de Control Vacio");
            } else {
                ps.setString(1, txt_ctrl.getText());
            }

            //INSERT NOMBRE
            if (txt_nom.getText().length() > 50 || txt_nom.getText().equals(null) || txt_nom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Nombre Invalido");
                txt_nom.setText("");
            }
            if (txt_nom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo De Nombre Vacio");
            } else {
                ps.setString(2, txt_nom.getText());
            }

            //INSERT SEMESTRE
            if (op_sem == 0) {
                JOptionPane.showMessageDialog(null, "Seleccione El Semestre");
            }
            ps.setString(3, String.valueOf(op_sem));

            //INSERT TELEFONO O CORREO
            if (txt_telf.getText().equals("") && txt_corr.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Ingrese al menos un metodo de contacto");
            }
            if (txt_telf.getText().length() > 10 || txt_telf.getText().matches(".*[a-z].*") || txt_telf.getText().matches(".*[A-Z].*")) {
                JOptionPane.showMessageDialog(null, "Numero Telefonico No Valido");
                txt_telf.setText("");
                txt_corr.setText("");
            }
            if (!txt_telf.getText().equals("") || !txt_corr.getText().equals("")) {
                ps.setString(4, txt_telf.getText());
                ps.setString(5, txt_corr.getText());
            }

            //INSERT FECHA DE NACIMIENTO
            if (txt_fecha.getText().matches(".*[a-z].*") || txt_fecha.getText().matches(".*[A-Z].*")) {
                JOptionPane.showMessageDialog(null, "Fecha De Nacimiento Invalida");
                txt_fecha.setText("");
            }
            if (txt_fecha.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo De Fecha Vacio");
            } else {
                ps.setDate(6, Date.valueOf(txt_fecha.getText()));
            }
            //INSERT CARRERA
            if (op_carr == 0) {
                JOptionPane.showMessageDialog(null, "Seleccione La Carrera");
            }
            if (op_carr == 1) {
                ps.setString(7, "ISC");
            }
            if (op_carr == 2) {
                ps.setString(7, "IGE");
            }
            if (op_carr == 3) {
                ps.setString(7, "IIN");
            }
            if (op_carr == 4) {
                ps.setString(7, "IME");
            }
            //VERFICACION Y EJECUCION DE NUESTRO QUERY
            int res = ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Datos Guardados");
            } else {
                JOptionPane.showMessageDialog(null, "Error Al Guardar Alumno");
            }
            conexion.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e);
        }
    }//GEN-LAST:event_btn_regActionPerformed

    private void txt_fechaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_fechaMouseClicked
        txt_fecha.setText("");        // TODO add your handling code here:
    }//GEN-LAST:event_txt_fechaMouseClicked

    private void btn_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limpiarActionPerformed
        btn_reg.setEnabled(true);
        txt_ctrl.setText("");
        txt_nom.setText("");
        combo_semestre.setSelectedIndex(0);
        txt_telf.setText("");
        txt_corr.setText("");
        combo_carrera.setSelectedIndex(0);
        txt_fecha.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_limpiarActionPerformed

    private void rb_ningunoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_ningunoMouseClicked
        tabla.setModel(new DefaultTableModel());
    }//GEN-LAST:event_rb_ningunoMouseClicked

    private void rb_iscMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_iscMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_iscMouseClicked

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        btn_reg.setEnabled(false);
        try {
            PreparedStatement ps = null;
            ResultSet rs = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();
            ps = conexion.prepareStatement("Select * FROM alumnos WHERE No_Ctrl = ?");
            ps.setString(1, txt_buscar.getText());

            rs = ps.executeQuery();
            int i;
            int j;
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Alumno Encontrado");
                txt_ctrl.setText(rs.getString("No_Ctrl"));
                txt_nom.setText(rs.getString("Nombre"));
                combo_semestre.setSelectedIndex(i = Integer.parseInt(rs.getString("Semestre")));
                txt_telf.setText(rs.getString("Numero_Telefonico"));
                txt_corr.setText(rs.getString("Correo_Electronico"));
                txt_fecha.setText(rs.getString("Fecha_Nacimiento"));
                if (rs.getString("Carrera").equals("ISC")) {
                    combo_carrera.setSelectedIndex(1);
                }
                if (rs.getString("Carrera").equals("IGE")) {
                    combo_carrera.setSelectedIndex(2);
                }
                if (rs.getString("Carrera").equals("IIN")) {
                    combo_carrera.setSelectedIndex(3);
                }
                if (rs.getString("Carrera").equals("IME")) {
                    combo_carrera.setSelectedIndex(4);
                }
                
            } else {
                JOptionPane.showMessageDialog(null, "No Existen Datos");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error" + e);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_elimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_elimActionPerformed
        try {
            PreparedStatement ps = null;
            mysqlconnection aux = new mysqlconnection();
            Connection conexion = aux.getConexion();
            ps = conexion.prepareStatement("DELETE FROM alumnos WHERE No_Ctrl=?");

            ps.setString(1, txt_buscar.getText());
            
            //VERFICACION Y EJECUCION DE NUESTRO QUERY
            int res = ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Alumno Eliminado");
                 btn_reg.setEnabled(true);
                 txt_ctrl.setText("");
                 txt_nom.setText("");
                 combo_semestre.setSelectedIndex(0);
                 txt_telf.setText("");
                 txt_corr.setText("");
                 combo_carrera.setSelectedIndex(0);
                 txt_fecha.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Error Al Eliminar Alumno");
            }
            conexion.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error" + e);
        }
        
        
    }//GEN-LAST:event_btn_elimActionPerformed

    private void rb_ningunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_ningunoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_ningunoActionPerformed

    public static void main(String args[]) {

        try {
            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // If Nimbus is not available, you can set the GUI to another look and feel.
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new App().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_elim;
    private javax.swing.JButton btn_limpiar;
    private javax.swing.JButton btn_modif;
    private javax.swing.JButton btn_reg;
    private javax.swing.JComboBox<String> combo_carrera;
    private javax.swing.JComboBox<String> combo_semestre;
    private javax.swing.JLabel fond;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.ButtonGroup rb_grupo;
    private javax.swing.JRadioButton rb_ige;
    private javax.swing.JRadioButton rb_iin;
    private javax.swing.JRadioButton rb_ime;
    private javax.swing.JRadioButton rb_isc;
    private javax.swing.JRadioButton rb_ninguno;
    private javax.swing.JRadioButton rb_todos;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txt_buscar;
    private javax.swing.JTextField txt_corr;
    private javax.swing.JTextField txt_ctrl;
    private javax.swing.JTextField txt_fecha;
    private javax.swing.JTextField txt_nom;
    private javax.swing.JTextField txt_telf;
    // End of variables declaration//GEN-END:variables
}
